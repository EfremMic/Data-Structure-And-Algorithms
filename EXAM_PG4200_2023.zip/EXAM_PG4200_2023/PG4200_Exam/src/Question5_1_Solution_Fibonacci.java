import java.sql.SQLOutput;

/*
Regardless of how fast computers become or how cheap memory gets, efficiency will always remain an important consideration.
To show the importance of developing efficient algorithms,compare these two algorithms:

- Recursive algorithm to solve fib(n) for 1 ≤ n ≤ 5 Fibonacci term
- Iterative algorithm to solve fib(n) for 1 ≤ n ≤ 5 Fibonacci term

Justify which algorithm is more efficient and why through the solution with code.
*/

public class Question5_1_Solution_Fibonacci {

    /**
     * Recursive implementation.
     * The function computes implementation for nth Fibonacci number.
     * Check if n is 1 or 0 and also returns value
     */
    static int recursiveFib(int n){
        if(n <= 1){
            return n;
        }
        return recursiveFib(n-1) + recursiveFib(n-2);
    }

    /**
     * Iterative implementation.
     * Computes the nth Fibonacci number
     * check if n is 1 or 0 and returns value
     * It initialize two variable
     * loop
     */
    public static int iterativeFib(int n) {
        if(n <= 1) {
            return n;
        }
        int curFib = 1;
        int prevFib = 1;

        for(int i=2; i<n; i++) {
            int temp = curFib;
            curFib+= prevFib;
            prevFib = temp;
        }
        return curFib;
    }

    public static void main(String[] args) {
        int i=5;

       for( int n=1; n<=i; n++){
           long startTime= System.nanoTime();
           recursiveFib(n);
           long endTime = System.nanoTime();
           long durRecursive= (endTime-startTime);
           System.out.println(n + " Recursive duration :" + durRecursive + "ns" );


           startTime = System.nanoTime();
           iterativeFib(n);
           endTime = System.nanoTime();
           long durIterative= (endTime-startTime);
           System.out.println(n + " Iterative duration: " + durIterative + "ns");
       }


    }
}

/**
 * IterativeFibonacci is more efficient than the recursive because of the run time. As we increase the n value up
 * to  5 , we can see that recursive takes much more time than iterative.
 *
 *
 * Here is the result for testing from 1 to 5:
 * 1 Recursive duration :3600ns
 * 1 Iterative duration: 3200ns
 * 2 Recursive duration :1000ns
 * 2 Iterative duration: 700ns
 * 3 Recursive duration :1000ns
 * 3 Iterative duration: 1100ns
 * 4 Recursive duration :1400ns
 * 4 Iterative duration: 1200ns
 * 5 Recursive duration :2000ns
 * 5 Iterative duration: 1400ns
 * */