
/*
Question: you are given N elements , and your task is to Implement a Stack in which you can get a minimum element in O(1) time.
You are required to complete the three methods:

- push() which takes one argument, an integer 'x' to be pushed into the stack,
- pop() which returns an integer popped out from the stack, and
- getMin() which returns the min element from the stack. (-1 will be returned if for pop() and getMin() the stack is empty.)

-  Constraints:
1 <= Number of queries <= 100
1 <= values of the stack <= 100
*/

//Import

import java.util.ArrayList;
import java.util.List;

/**
 * stack that supports push, pop, top, and retrieving the minimum element in constant time.
 * push(x) -- Push element x onto stack.
 * pop() -- Removes element at the top of the stack.
 * getMin() -- Retrieve the minimum element from the stack.
 */
public class Question2_2_Solution_Stack {
    private List<Integer> elements = new ArrayList<Integer>();
    private Integer minElement = Integer.MAX_VALUE;


    // Time: O(1)
    // Space: O(1)

    /**
     * Not sure if constraint means that x should be within the range of 1 to 100 or that the stack can only contain
     * at most 100 items
     */
    public void push(int x) {
        // if (elements.size() == 100) {
        //   // Throw an exception per the constraint
        //   throw new Exception("Stack cannot store more than 100 elements");
        // }
        //if(x<1 || x>100){
        //   throw new Exception(" x can only be between 1 and 100");
        // }
        elements.add(x);
        if (x < minElement) {
            minElement = x;
        }
    }

    // Time: O(1)
    // Space: O(1)
    public int pop() {
        if (elements.size() == 0) {
            // No elements to pop
            return -1;
        }
        int indexOfLastItem = elements.size() - 1;
        Integer result = elements.remove(indexOfLastItem);

        if (elements.size() == 0) {
            // I've removed all elements
            // Reset the minElements to max possible integer
            minElement = Integer.MAX_VALUE;
        }

        return result;
    }

    // Time: O(1)
    // Space: O(1)
    public int getMin() {
        if (elements.size() == 0) {
            // Stack is empty
            return -1;
        }
        return minElement;
    }

    public static void main(String[] args) {
        // Testing logic
        Question2_2_Solution_Stack stack = new Question2_2_Solution_Stack();
        stack.push(1);
        stack.push(40);
        stack.pop();
        stack.push(28);
        stack.getMin();
    }
}
